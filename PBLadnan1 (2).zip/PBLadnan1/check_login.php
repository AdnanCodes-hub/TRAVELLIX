<?php
session_start();

function isLoggedIn() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}

function getUserName() {
    return $_SESSION['full_name'] ?? '';
}

// If accessing this file directly, redirect to login
if (basename($_SERVER['PHP_SELF']) == 'check_login.php') {
    header('Location: login.html');
    exit();
}
?> 