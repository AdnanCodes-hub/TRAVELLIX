<?php
// Prevent any output before JSON response
ob_start();

// Disable error display and set error handling
error_reporting(0);
ini_set('display_errors', 0);

// Start the session
session_start();

// Set JSON header
header('Content-Type: application/json');

require_once 'db_connection.php';

// Function to send JSON response
function sendJsonResponse($success, $message, $redirect = null) {
    ob_clean(); // Clear any previous output
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'redirect' => $redirect
    ]);
    exit;
}

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    sendJsonResponse(false, 'Invalid request method');
}

// Get and validate form data
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// Basic validation
if (empty($email) || empty($password)) {
    sendJsonResponse(false, 'Please fill in all fields');
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    sendJsonResponse(false, 'Invalid email format');
}

try {
    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT id, full_name, email, password FROM users WHERE email = ?");
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("s", $email);
    
    // Execute the statement
    if (!$stmt->execute()) {
        throw new Exception("Error executing statement: " . $stmt->error);
    }

    // Get the result
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Password is correct, set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['logged_in'] = true;

            // Send success response
            sendJsonResponse(true, 'Login successful!', 'Home.html');
        } else {
            // Invalid password
            sendJsonResponse(false, 'Invalid email or password');
        }
    } else {
        // User not found
        sendJsonResponse(false, 'Invalid email or password');
    }

} catch (Exception $e) {
    // Log the error (in a production environment)
    error_log("Login error: " . $e->getMessage());
    
    // Send generic error message to user
    sendJsonResponse(false, 'An error occurred during login. Please try again.');
} finally {
    // Close statement and connection
    if (isset($stmt)) {
        $stmt->close();
    }
    if (isset($conn)) {
        $conn->close();
    }
}
?> 