<?php
// Prevent any output before JSON response
ob_start();

// Disable error display and set error handling
error_reporting(0);
ini_set('display_errors', 0);

// Start the session
session_start();

// Set JSON header
header('Content-Type: application/json');

require_once 'db_connection.php';

// Function to send JSON response
function sendJsonResponse($success, $message) {
    ob_clean(); // Clear any previous output
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    sendJsonResponse(false, 'Please login to submit a review');
}

// Get user_id from session
$user_id = $_SESSION['user_id'];

// Check connection
if ($conn->connect_error) {
    sendJsonResponse(false, "Connection failed: " . $conn->connect_error);
}

// Get and validate form data
$package_id = isset($_POST['package_id']) ? intval($_POST['package_id']) : 0;
$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;
$comment = isset($_POST['comment']) ? trim($_POST['comment']) : '';

// Validate input
if ($package_id <= 0) {
    sendJsonResponse(false, 'Invalid package selected');
}

if ($rating < 1 || $rating > 5) {
    sendJsonResponse(false, 'Invalid rating value');
}

if (empty($comment)) {
    sendJsonResponse(false, 'Review comment is required');
}

try {
    // First verify that the package exists
    $check_package = $conn->prepare("SELECT id FROM packages WHERE id = ?");
    if (!$check_package) {
        throw new Exception("Error preparing package check: " . $conn->error);
    }
    
    $check_package->bind_param("i", $package_id);
    if (!$check_package->execute()) {
        throw new Exception("Error checking package: " . $check_package->error);
    }
    
    $result = $check_package->get_result();
    if ($result->num_rows === 0) {
        throw new Exception("Selected package does not exist");
    }
    $check_package->close();

    // Prepare the SQL statement for inserting the review
    $stmt = $conn->prepare("INSERT INTO reviews (user_id, package_id, rating, comment, review_date) VALUES (?, ?, ?, ?, NOW())");
    if (!$stmt) {
        throw new Exception("Error preparing review insert: " . $conn->error);
    }

    // Bind parameters
    if (!$stmt->bind_param("iiis", $user_id, $package_id, $rating, $comment)) {
        throw new Exception("Error binding parameters: " . $stmt->error);
    }
    
    // Execute the statement
    if (!$stmt->execute()) {
        throw new Exception("Error executing review insert: " . $stmt->error);
    }

    // Success response
    sendJsonResponse(true, 'Review submitted successfully');

} catch (Exception $e) {
    // Error response
    http_response_code(400);
    sendJsonResponse(false, $e->getMessage());
} finally {
    // Close statement and connection
    if (isset($stmt)) {
        $stmt->close();
    }
    if (isset($check_package)) {
        $check_package->close();
    }
    $conn->close();
}
?>