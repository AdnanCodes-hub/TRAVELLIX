<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'db_connection.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

try {
    // Drop existing tables if they exist
    $conn->query("DROP TABLE IF EXISTS contact");
    $conn->query("DROP TABLE IF EXISTS reviews");
    $conn->query("DROP TABLE IF EXISTS bookings");
    $conn->query("DROP TABLE IF EXISTS packages");
    $conn->query("DROP TABLE IF EXISTS users");

    // Create users table
    $create_users = "CREATE TABLE users (
        id INT NOT NULL AUTO_INCREMENT,
        full_name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        phone VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    if (!$conn->query($create_users)) {
        throw new Exception("Error creating users table: " . $conn->error);
    }

    // Create packages table
    $create_packages = "CREATE TABLE packages (
        id INT NOT NULL AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL,
        description TEXT NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        duration VARCHAR(50) NOT NULL,
        features TEXT NOT NULL,
        image_url VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    if (!$conn->query($create_packages)) {
        throw new Exception("Error creating packages table: " . $conn->error);
    }

    // Create bookings table
    $create_bookings = "CREATE TABLE bookings (
        id INT NOT NULL AUTO_INCREMENT,
        user_id INT NOT NULL,
        package_id INT NOT NULL,
        booking_date DATE NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        number_of_travelers INT NOT NULL,
        total_price DECIMAL(10,2) NOT NULL,
        payment_method VARCHAR(50) NOT NULL,
        booking_status VARCHAR(50) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    if (!$conn->query($create_bookings)) {
        throw new Exception("Error creating bookings table: " . $conn->error);
    }

    // Create reviews table
    $create_reviews = "CREATE TABLE reviews (
        id INT NOT NULL AUTO_INCREMENT,
        user_id INT NOT NULL,
        package_id INT NOT NULL,
        rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
        comment TEXT NOT NULL,
        review_date DATETIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    if (!$conn->query($create_reviews)) {
        throw new Exception("Error creating reviews table: " . $conn->error);
    }

    // Create contact table
    $create_contact = "CREATE TABLE contact (
        id INT NOT NULL AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        subject VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        contact_date DATETIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    if (!$conn->query($create_contact)) {
        throw new Exception("Error creating contact table: " . $conn->error);
    }

    // Insert sample data
    // Users
    $users = [
        ['full_name' => 'John Doe', 'email' => 'john@example.com', 'password' => '123456', 'phone' => '1234567890'],
        ['full_name' => 'Sarah Smith', 'email' => 'sarah@example.com', 'password' => '$2y10abikDanNQTm7CZAQK0X7fkeOws0qVQZiv5P1B.MBgpBY.', 'phone' => '+1987654321'],
        ['full_name' => 'Adnan Mehdi', 'email' => 'onlyadnan17@gmail.com', 'password' => '$2y10nhHrhoOYmnddr3PbYPVUaudLLWKB6taX4YeYnTPnMc', 'phone' => '03170529740'],
        ['full_name' => 'Adnan Mehdi', 'email' => 'f24607042@nutech.edu.pk', 'password' => '$2y10iXb0cg', 'phone' => '']
    ];

    $stmt = $conn->prepare("INSERT INTO users (full_name, email, password, phone) VALUES (?, ?, ?, ?)");
    foreach ($users as $user) {
        $stmt->bind_param("ssss", $user['full_name'], $user['email'], $user['password'], $user['phone']);
        if (!$stmt->execute()) {
            throw new Exception("Error inserting user: " . $stmt->error);
        }
    }

    // Packages
    $packages = [
        ['name' => 'Beach Paradise', 'description' => 'Beautiful beach vacation', 'price' => 999.99, 'duration' => '7 Days', 'features' => 'Hotel, Meals, Tours', 'image_url' => 'beach.jpg'],
        ['name' => 'Mountain Trek', 'description' => 'Mountain adventure package', 'price' => 799.99, 'duration' => '5 Days', 'features' => 'Camping, Guide, Equipment', 'image_url' => 'mountain.jpg'],
        ['name' => 'City Explorer', 'description' => 'Urban adventure package', 'price' => 1299.99, 'duration' => '6 Days', 'features' => 'Hotel, Tours, Transport', 'image_url' => 'city.jpg'],
        ['name' => 'Desert Safari', 'description' => 'Exciting desert adventure package', 'price' => 899.00, 'duration' => '4 Days', 'features' => 'Camping, Meals, Safari Tours', 'image_url' => 'desert.jpg'],
        ['name' => 'Forest Retreat', 'description' => 'Peaceful forest getaway package', 'price' => 1199.00, 'duration' => '5 Days', 'features' => 'Lodge, Meals, Nature Walks', 'image_url' => 'forest.jpg'],
        ['name' => 'Island Hopping', 'description' => 'Tropical island adventure package', 'price' => 1799.00, 'duration' => '7 Days', 'features' => 'Resort, Meals, Boat Tours', 'image_url' => 'island.jpg']
    ];

    $stmt = $conn->prepare("INSERT INTO packages (name, description, price, duration, features, image_url) VALUES (?, ?, ?, ?, ?, ?)");
    foreach ($packages as $package) {
        $stmt->bind_param("ssdsss", $package['name'], $package['description'], $package['price'], $package['duration'], $package['features'], $package['image_url']);
        if (!$stmt->execute()) {
            throw new Exception("Error inserting package: " . $stmt->error);
        }
    }

    // Reviews
    $reviews = [
        ['user_id' => 1, 'package_id' => 1, 'rating' => 5, 'comment' => 'Amazing experience!', 'review_date' => '2024-03-15'],
        ['user_id' => 1, 'package_id' => 1, 'rating' => 5, 'comment' => 'Amazing beach experience! The resort was fantastic.', 'review_date' => '2024-03-01'],
        ['user_id' => 2, 'package_id' => 2, 'rating' => 4, 'comment' => 'Great vacation package! The beach was beautiful and the activities were fun.', 'review_date' => '2024-03-05'],
        ['user_id' => 1, 'package_id' => 2, 'rating' => 4, 'comment' => 'The mountain trek was breathtaking! Our guide was excellent.', 'review_date' => '2024-03-10'],
        ['user_id' => 2, 'package_id' => 3, 'rating' => 3, 'comment' => 'Loved exploring the city! The hotel was in a perfect location.', 'review_date' => '2024-03-15'],
        ['user_id' => 1, 'package_id' => 3, 'rating' => 3, 'comment' => 'Perfect city break! Got to see all the major attractions.', 'review_date' => '2024-03-20']
    ];

    $stmt = $conn->prepare("INSERT INTO reviews (user_id, package_id, rating, comment, review_date) VALUES (?, ?, ?, ?, ?)");
    foreach ($reviews as $review) {
        $stmt->bind_param("iiiss", $review['user_id'], $review['package_id'], $review['rating'], $review['comment'], $review['review_date']);
        if (!$stmt->execute()) {
            throw new Exception("Error inserting review: " . $stmt->error);
        }
    }

    // Contact
    $contacts = [
        ['name' => 'Jane Smith', 'email' => 'jane@example.com', 'subject' => 'Package Query', 'message' => 'I need more information about Beach Paradise package.', 'contact_date' => '2024-03-15'],
        ['name' => 'Adnan Mehdi', 'email' => 'onlyadnan17@gmail.com', 'subject' => 'Contact Inquiry', 'message' => 'Hi', 'contact_date' => '2025-05-29'],
        ['name' => 'Adnan Mehdi', 'email' => 'adnanx34101@gmail.com', 'subject' => 'Contact Inquiry', 'message' => 'My name is Adnan', 'contact_date' => '2025-05-29'],
        ['name' => 'Ahmad Khan', 'email' => 'onlyadnan17@gmail.com', 'subject' => 'Contact Inquiry', 'message' => 'Salam o Alaikum', 'contact_date' => '2025-05-29']
    ];

    $stmt = $conn->prepare("INSERT INTO contact (name, email, subject, message, contact_date) VALUES (?, ?, ?, ?, ?)");
    foreach ($contacts as $contact) {
        $stmt->bind_param("sssss", $contact['name'], $contact['email'], $contact['subject'], $contact['message'], $contact['contact_date']);
        if (!$stmt->execute()) {
            throw new Exception("Error inserting contact: " . $stmt->error);
        }
    }

    echo "All tables created and sample data inserted successfully!";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

$conn->close();
?> 