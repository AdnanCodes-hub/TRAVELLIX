<?php
header('Content-Type: application/json');

// Database connection
$host = 'localhost';
$dbname = 'travellix';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $stmt = $pdo->prepare("SELECT * FROM packages WHERE id = ?");
        $stmt->execute([$id]);
        $package = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($package) {
            echo json_encode([
                'success' => true,
                'package' => $package
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Package not found'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No package ID provided'
        ]);
    }
} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?> 