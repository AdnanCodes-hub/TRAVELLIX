 <?php
header('Content-Type: application/json');

// Database configuration
$host = 'localhost';        // or your host
$dbname = 'travellix';   // replace with your actual DB name
$user = 'root';             // your DB username
$pass = '';                 // your DB password

try {
    // Create a new PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Query to fetch all packages
    $stmt = $pdo->query("SELECT id, name, price, duration, features, image_url FROM packages");

    $packages = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Send JSON response
    echo json_encode([
        'success' => true,
        'packages' => $packages
    ]);

} catch (PDOException $e) {
    // If there's an error, return JSON error response
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
