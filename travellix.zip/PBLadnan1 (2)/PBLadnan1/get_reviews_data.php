<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Database connection parameters
$host = 'localhost';
$dbname = 'travellix';
$username = 'root';
$password = '';

try {
    // Create database connection
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get packages with review counts
    $packages_query = "
        SELECT p.*, COUNT(r.id) as review_count, AVG(r.rating) as avg_rating
        FROM packages p
        LEFT JOIN reviews r ON p.id = r.package_id
        GROUP BY p.id
    ";
    $packages = $conn->query($packages_query)->fetchAll(PDO::FETCH_ASSOC);

    // Get reviews with user and package info
    $reviews_query = "
        SELECT r.*, u.email as reviewer_name, p.name as package_name,
               DATE_FORMAT(r.review_date, '%M %d, %Y') as formatted_date
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        JOIN packages p ON r.package_id = p.id
        ORDER BY r.review_date DESC
        LIMIT 10
    ";
    $reviews = $conn->query($reviews_query)->fetchAll(PDO::FETCH_ASSOC);

    // Get review statistics
    $stats_query = "
        SELECT 
            COUNT(*) as total_reviews,
            ROUND(AVG(rating), 1) as avg_rating,
            MIN(rating) as min_rating,
            MAX(rating) as max_rating
        FROM reviews
    ";
    $stats = $conn->query($stats_query)->fetch(PDO::FETCH_ASSOC);

    // Get rating distribution
    $dist_query = "
        SELECT rating, COUNT(*) as count,
               ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM reviews), 1) as percentage
        FROM reviews
        GROUP BY rating
        ORDER BY rating DESC
    ";
    $rating_distribution = $conn->query($dist_query)->fetchAll(PDO::FETCH_ASSOC);

    // Get package statistics
    $package_stats_query = "
        SELECT p.name as package_name,
               COUNT(r.id) as review_count,
               ROUND(AVG(r.rating), 1) as avg_package_rating
        FROM packages p
        LEFT JOIN reviews r ON p.id = r.package_id
        GROUP BY p.id
        ORDER BY review_count DESC
    ";
    $package_stats = $conn->query($package_stats_query)->fetchAll(PDO::FETCH_ASSOC);

    // Return all data
    echo json_encode([
        'success' => true,
        'packages' => $packages,
        'reviews' => $reviews,
        'stats' => $stats,
        'rating_distribution' => $rating_distribution,
        'package_stats' => $package_stats
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching reviews: ' . $e->getMessage()
    ]);
}
?> 