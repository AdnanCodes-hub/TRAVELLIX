<?php
require_once 'db_connection.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $firstName = mysqli_real_escape_string($conn, $_POST['firstName']);
    $lastName = mysqli_real_escape_string($conn, $_POST['lastName']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $package = mysqli_real_escape_string($conn, $_POST['package']);
    $travelers = (int)$_POST['travelers'];
    $startDate = mysqli_real_escape_string($conn, $_POST['startDate']);
    $endDate = mysqli_real_escape_string($conn, $_POST['endDate']);
    $paymentMethod = mysqli_real_escape_string($conn, $_POST['payment_method']);
    
    // Calculate total price based on package selection
    $priceMap = array(
        'Beach Paradise' => 999,
        'Mountain Adventure' => 1299,
        'City Explorer' => 1499,
        'Desert Safari' => 899,
        'Forest Retreat' => 1199,
        'Island Hopping' => 1799
    );
    
    $pricePerPerson = isset($priceMap[$package]) ? $priceMap[$package] : 0;
    $totalPrice = $pricePerPerson * $travelers;
    
    // Get current user ID (you may need to implement your own user system)
    $userId = 1; // Default user ID for now
    
    // Set package ID (you may need to implement your own package system)
    $packageId = 1; // Default package ID for now
    
    // Set initial booking status
    $bookingStatus = 'Confirmed';
    
    // Current date for booking_date
    $bookingDate = date('Y-m-d');
    
    // Prepare SQL statement matching your table structure
    $sql = "INSERT INTO bookings (user_id, package_id, booking_date, start_date, end_date, 
            number_of_travelers, total_price, payment_method, booking_status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    // Create prepared statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind parameters
        $stmt->bind_param("iisssidss", 
            $userId,
            $packageId,
            $bookingDate,
            $startDate,
            $endDate,
            $travelers,
            $totalPrice,
            $paymentMethod,
            $bookingStatus
        );
        
        // Execute the statement
        if ($stmt->execute()) {
            // Get the booking ID
            $bookingId = $conn->insert_id;
            
            // Redirect to success page
            header("Location: booking_success.html?booking_id=" . $bookingId);
            exit();
        } else {
            echo "Error: " . $stmt->error;
            // Redirect back to booking form with error
            header("Location: Bookings.html?error=1&message=" . urlencode("Booking failed. Please try again."));
            exit();
        }
        
        // Close statement
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
        header("Location: Bookings.html?error=1&message=" . urlencode("System error. Please try again."));
        exit();
    }
    
    // Close connection
    $conn->close();
    
} else {
    // If not POST request, redirect to booking form
    header("Location: Bookings.html");
    exit();
}
?> 