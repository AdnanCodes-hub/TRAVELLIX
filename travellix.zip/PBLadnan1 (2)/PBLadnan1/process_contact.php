<?php
session_start();
require_once 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $message = trim($_POST['message']);
    $subject = "Contact Inquiry"; // Default subject
    $contact_date = date('Y-m-d'); // Current date
    
    // Basic validation
    if (empty($name) || empty($email) || empty($message)) {
        header("Location: contactus.html?error=" . urlencode("Please fill in all required fields"));
        exit();
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: contactus.html?error=" . urlencode("Invalid email format"));
        exit();
    }

    // Create table if it doesn't exist
    $create_table = "CREATE TABLE IF NOT EXISTS contact (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        subject VARCHAR(200) NOT NULL,
        message TEXT NOT NULL,
        contact_date DATE NOT NULL
    )";
    
    if ($conn->query($create_table) === FALSE) {
        header("Location: contactus.html?error=" . urlencode("Error creating table: " . $conn->error));
        exit();
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO contact (name, email, subject, message, contact_date) VALUES (?, ?, ?, ?, ?)");
    if ($stmt === FALSE) {
        header("Location: contactus.html?error=" . urlencode("Prepare failed: " . $conn->error));
        exit();
    }

    $stmt->bind_param("sssss", $name, $email, $subject, $message, $contact_date);

    // Execute the statement
    if ($stmt->execute()) {
        header("Location: contactus.html?success=" . urlencode("Thank you for your message! We will get back to you soon."));
    } else {
        header("Location: contactus.html?error=" . urlencode("Failed to send message. Please try again."));
    }

    $stmt->close();
    $conn->close();
} else {
    // If someone tries to access this file directly
    header("Location: contactus.html");
}
?> 