<?php
session_start();
require_once 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    
    // Basic validation
    if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
        header("Location: signup.html?error=" . urlencode("All fields are required"));
        exit();
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: signup.html?error=" . urlencode("Invalid email format"));
        exit();
    }

    // Check if email already exists
    $check_email = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check_email->bind_param("s", $email);
    $check_email->execute();
    $result = $check_email->get_result();
    
    if ($result->num_rows > 0) {
        header("Location: signup.html?error=" . urlencode("Email already exists"));
        exit();
    }
    $check_email->close();

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO users (full_name, email, password, phone) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $full_name, $email, $hashed_password, $phone);

    // Execute the statement
    if ($stmt->execute()) {
        header("Location: login.html?success=" . urlencode("Registration successful! Please login."));
    } else {
        header("Location: signup.html?error=" . urlencode("Registration failed. Please try again."));
    }

    $stmt->close();
    $conn->close();
} else {
    // If someone tries to access this file directly
    header("Location: signup.html");
}
?> 