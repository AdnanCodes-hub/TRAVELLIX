<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'db_connection.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if tables exist
$tables_check = "
    SELECT COUNT(*) as count 
    FROM information_schema.tables 
    WHERE table_schema = DATABASE() 
    AND table_name IN ('reviews', 'packages')";
$tables_result = $conn->query($tables_check);
$tables_data = $tables_result->fetch_assoc();

if ($tables_data['count'] < 2) {
    die("Error: Required tables (reviews and/or packages) do not exist in the database.");
}

// Rest of your queries with error checking
try {
    // Count total reviews
    $total_query = "SELECT COUNT(*) as total FROM reviews";
    $total_result = $conn->query($total_query);
    if (!$total_result) {
        throw new Exception("Error executing total query: " . $conn->error);
    }
    $total_data = $total_result->fetch_assoc();

    // Get average rating
    $avg_query = "SELECT ROUND(AVG(rating), 1) as avg_rating FROM reviews";
    $avg_result = $conn->query($avg_query);
    if (!$avg_result) {
        throw new Exception("Error executing average query: " . $conn->error);
    }
    $avg_data = $avg_result->fetch_assoc();

    // Get min and max ratings
    $minmax_query = "SELECT 
        MIN(rating) as min_rating,
        MAX(rating) as max_rating,
        MIN(review_date) as earliest_date,
        MAX(review_date) as latest_date
    FROM reviews";
    $minmax_result = $conn->query($minmax_query);
    if (!$minmax_result) {
        throw new Exception("Error executing min/max query: " . $conn->error);
    }
    $minmax_data = $minmax_result->fetch_assoc();

    // Get package statistics
    $package_stats = "SELECT 
        p.name as package_name,
        COUNT(r.id) as review_count,
        ROUND(AVG(r.rating), 1) as avg_package_rating
    FROM packages p
    LEFT JOIN reviews r ON p.package_id = r.package_id
    GROUP BY p.package_id, p.name
    ORDER BY avg_package_rating DESC, review_count DESC";
    $package_result = $conn->query($package_stats);
    if (!$package_result) {
        throw new Exception("Error executing package stats query: " . $conn->error);
    }

    // Get recent reviews with user information
    $reviews_query = "SELECT 
        r.*,
        p.name as package_name,
        u.email as reviewer_email,
        DATE_FORMAT(r.review_date, '%Y-%m-%d') as formatted_date
    FROM reviews r
    JOIN packages p ON r.package_id = p.package_id
    LEFT JOIN users u ON r.user_id = u.id
    ORDER BY r.review_date DESC
    LIMIT 10";
    $reviews_result = $conn->query($reviews_query);
    if (!$reviews_result) {
        throw new Exception("Error executing reviews query: " . $conn->error);
    }

    // Get rating distribution
    $rating_dist_query = "SELECT 
        rating,
        COUNT(*) as count,
        ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM reviews), 1) as percentage
    FROM reviews
    GROUP BY rating
    ORDER BY rating DESC";
    $rating_dist_result = $conn->query($rating_dist_query);
    if (!$rating_dist_result) {
        throw new Exception("Error executing rating distribution query: " . $conn->error);
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Travellix - Reviews</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Header and Navigation Styles */
        header, footer {
            background-color: #1a1a1a;
            color: #ffd600;
            padding: 15px 30px;
        }

        /* Rest of your existing styles */

        /* Statistics Styles */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border-left: 4px solid #ffd600;
        }

        .stat-card h3 {
            color: #333;
            margin-bottom: 10px;
            font-size: 1.2em;
        }

        .stat-value {
            font-size: 1.8em;
            color: #ffd600;
            font-weight: bold;
        }

        .package-stats {
            margin-top: 20px;
        }

        .package-stat-row {
            display: flex;
            justify-content: space-between;
            padding: 10px;
            border-bottom: 1px solid #eee;
        }

        .package-stat-row:last-child {
            border-bottom: none;
        }

        .rating-bar {
            background: #f0f0f0;
            height: 20px;
            border-radius: 10px;
            overflow: hidden;
            margin: 5px 0;
        }

        .rating-fill {
            background: #ffd600;
            height: 100%;
            transition: width 0.3s ease;
        }
    </style>
</head>
<body>

<header>
    <div class="logo">
        <a href="Home.html">Travellix</a>
    </div>
    <nav>
        <a href="Home.html">Home</a>
        <a href="destinations.html">Destinations</a>
        <a href="packages.html">Packages</a>
        <a href="reviews.php" class="active">Reviews</a>
        <a href="Bookings.html">Book Now</a>
        <a href="contactus.html">Contact us</a>
        <a href="Aboutus.html">About us</a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="logout.php" class="login-btn">Logout</a>
        <?php else: ?>
            <a href="login.html" class="login-btn">Login</a>
        <?php endif; ?>
    </nav>
</header>

<main class="main-content">
    <!-- Statistics Section -->
    <div class="stats-container">
        <div class="stat-card">
            <h3>Overview Statistics</h3>
            <div class="stat-item">
                <p>Total Reviews: <span class="stat-value"><?php echo $total_data['total']; ?></span></p>
                <p>Average Rating: <span class="stat-value"><?php echo $avg_data['avg_rating']; ?> ★</span></p>
                <p>Rating Range: <span class="stat-value"><?php echo $minmax_data['min_rating']; ?>-<?php echo $minmax_data['max_rating']; ?> ★</span></p>
            </div>
        </div>

        <div class="stat-card">
            <h3>Rating Distribution</h3>
            <?php while($rating = $rating_dist_result->fetch_assoc()): ?>
                <div class="rating-item">
                    <p><?php echo str_repeat('★', $rating['rating']) . str_repeat('☆', 5 - $rating['rating']); ?></p>
                    <div class="rating-bar">
                        <div class="rating-fill" style="width: <?php echo $rating['percentage']; ?>%"></div>
                    </div>
                    <p><?php echo $rating['count']; ?> reviews (<?php echo $rating['percentage']; ?>%)</p>
                </div>
            <?php endwhile; ?>
        </div>

        <div class="stat-card">
            <h3>Package Statistics</h3>
            <div class="package-stats">
                <?php while($package = $package_result->fetch_assoc()): ?>
                    <div class="package-stat-row">
                        <span><?php echo htmlspecialchars($package['package_name']); ?></span>
                        <span><?php echo $package['review_count']; ?> reviews (<?php echo $package['avg_package_rating']; ?> ★)</span>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>

    <!-- Reviews Section -->
    <section class="reviews-section">
        <div class="reviews-container">
            <?php if($reviews_result->num_rows > 0): ?>
                <?php while($review = $reviews_result->fetch_assoc()): ?>
                    <div class="review-card">
                        <div class="review-header">
                            <span class="reviewer-name"><?php echo htmlspecialchars($review['reviewer_email'] ?? 'Anonymous'); ?></span>
                            <span class="review-rating">
                                <?php echo str_repeat('★', $review['rating']) . str_repeat('☆', 5 - $review['rating']); ?>
                            </span>
                        </div>
                        <div class="review-date"><?php echo $review['formatted_date']; ?></div>
                        <div class="review-package">Package: <?php echo htmlspecialchars($review['package_name']); ?></div>
                        <div class="review-content"><?php echo htmlspecialchars($review['comment']); ?></div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="review-card">
                    <p>No reviews available yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Review Form Section -->
    <section class="form-section">
        <h2>Write a Review</h2>
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="error-message" id="errorMessage"></div>
            <div class="success-message" id="successMessage"></div>
            <form id="reviewForm" action="process_review.php" method="POST" onsubmit="return submitReview(event)">
                <div class="form-group">
                    <label>Rating</label>
                    <div class="star-rating">
                        <input type="radio" id="star5" name="rating" value="5" checked>
                        <label for="star5">★</label>
                        <input type="radio" id="star4" name="rating" value="4">
                        <label for="star4">★</label>
                        <input type="radio" id="star3" name="rating" value="3">
                        <label for="star3">★</label>
                        <input type="radio" id="star2" name="rating" value="2">
                        <label for="star2">★</label>
                        <input type="radio" id="star1" name="rating" value="1">
                        <label for="star1">★</label>
                    </div>
                </div>

                <div class="form-group">
                    <label for="package">Select Package</label>
                    <select id="package" name="package_id" required>
                        <option value="">Choose a package...</option>
                        <?php
                        $packages_query = "SELECT id, name FROM packages ORDER BY name";
                        $packages_result = $conn->query($packages_query);
                        while($package = $packages_result->fetch_assoc()): 
                        ?>
                            <option value="<?php echo $package['id']; ?>">
                                <?php echo htmlspecialchars($package['name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="review">Your Review</label>
                    <textarea id="review" name="comment" required placeholder="Share your experience..."></textarea>
                </div>

                <button type="submit" class="submit-btn">Submit Review</button>
            </form>
        <?php else: ?>
            <div class="login-prompt">
                <p>Please <a href="login.html">login</a> to write a review.</p>
            </div>
        <?php endif; ?>
    </section>
</main>

<footer>
    <p>&copy; 2024 Alpha Squad. All rights reserved.</p>
</footer>

<script>
// Show error message
function showError(message) {
    const errorDiv = document.getElementById('errorMessage');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    setTimeout(() => {
        errorDiv.style.display = 'none';
    }, 5000);
}

// Show success message
function showSuccess(message) {
    const successDiv = document.getElementById('successMessage');
    successDiv.textContent = message;
    successDiv.style.display = 'block';
    setTimeout(() => {
        successDiv.style.display = 'none';
    }, 5000);
}

// Handle form submission
async function submitReview(event) {
    event.preventDefault();
    const form = event.target;
    const submitBtn = form.querySelector('.submit-btn');
    const originalBtnText = submitBtn.textContent;
    
    // Clear previous messages
    document.getElementById('errorMessage').style.display = 'none';
    document.getElementById('successMessage').style.display = 'none';
    
    try {
        // Validate form
        const package_id = form.package_id.value;
        const selectedRatingInput = form.querySelector('input[name="rating"]:checked');
        const rating = selectedRatingInput ? selectedRatingInput.value : null;
        const comment = form.comment.value;

        if (!package_id) {
            throw new Error('Please select a package');
        }
        if (!rating) {
            throw new Error('Please select a rating');
        }
        if (!comment.trim()) {
            throw new Error('Please enter your review');
        }
        if (comment.length < 10) {
            throw new Error('Review must be at least 10 characters long');
        }

        // Disable form and show loading state
        submitBtn.innerHTML = '<span class="loading-spinner"></span>Submitting...';
        submitBtn.disabled = true;
        form.classList.add('disabled');

        const formData = new FormData(form);
        // Ensure rating is sent as an integer
        formData.set('rating', parseInt(rating, 10));

        const response = await fetch('process_review.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error('Failed to submit review. Please try again.');
        }

        const result = await response.json();
        
        if (result.success) {
            showSuccess(result.message);
            form.reset();
            // Reload the page to show the new review
            window.location.reload();
        } else {
            throw new Error(result.message || 'Failed to submit review');
        }
    } catch (error) {
        console.error('Submission error:', error);
        showError(error.message);
    } finally {
        // Reset form state
        submitBtn.innerHTML = originalBtnText;
        submitBtn.disabled = false;
        form.classList.remove('disabled');
    }
    
    return false;
}
</script>

</body>
</html>
<?php $conn->close(); ?> 